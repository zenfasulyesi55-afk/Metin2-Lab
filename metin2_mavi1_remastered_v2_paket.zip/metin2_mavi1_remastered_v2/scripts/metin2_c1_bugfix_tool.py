#!/usr/bin/env python3
"""Metin2 Mavi 1. Koy V2 Bug-Fix & Validator (areadata, CRC32, attr.atr spawn check)"""
import os, re, argparse

ATTR_BLOCK, ATTR_WATER, ATTR_OBJECT = 0x01, 0x02, 0x80

def scan_properties(prop_dir):
    crc_map, dups = {}, []
    if not prop_dir or not os.path.isdir(prop_dir):
        return crc_map, dups
    for root, _, files in os.walk(prop_dir):
        for fn in files:
            if fn.lower().endswith((".prb", ".pre", ".prd", ".prt", ".pra")):
                full = os.path.join(root, fn)
                with open(full, "r", encoding="utf-8", errors="ignore") as f:
                    lines = [ln.strip() for ln in f if ln.strip()]
                if len(lines) >= 2 and lines[0] == "YPRT":
                    if lines[1] in crc_map:
                        dups.append((lines[1], crc_map[lines[1]], full))
                    else:
                        crc_map[lines[1]] = full
    return crc_map, dups

def parse_areadata(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()
    pat = re.compile(
        r"Start\s+Object\d+\s+([-+]?\d*\.?\d+)\s+([-+]?\d*\.?\d+)\s+([-+]?\d*\.?\d+)\s+"
        r"(\d+)\s+([^\n]+)\s+([-+]?\d*\.?\d+)\s+End\s+Object", re.M)
    return [{"x": float(m[1]), "y": float(m[2]), "z": float(m[3]), "crc": m[4],
             "rot": m[5].strip(), "bias": float(m[6])} for m in pat.finditer(text)]

def write_areadata(path, objs):
    with open(path, "w", encoding="utf-8") as f:
        f.write("AreaDataFile\n")
        for i, o in enumerate(objs):
            f.write(f"Start Object{i:03d}\n    {o['x']:.6f} {o['y']:.6f} {o['z']:.6f}\n"
                    f"    {o['crc']}\n    {o['rot']}\n    {o['bias']:.6f}\nEnd Object\n")

def run(map_dir, prop_dir, fix):
    crc_map, dup_crcs = scan_properties(prop_dir)
    print(f"[INFO] Property CRC tarandi: {len(crc_map)} | Cakisma: {len(dup_crcs)}")
    pos_y = dups = missing = 0
    for entry in sorted(os.listdir(map_dir)):
        cdir = os.path.join(map_dir, entry)
        af = os.path.join(cdir, "areadata.txt")
        if not (os.path.isdir(cdir) and len(entry) == 6 and entry.isdigit() and os.path.isfile(af)):
            continue
        objs = parse_areadata(af)
        clean, seen, mod = [], [], False
        for o in objs:
            if o["y"] > 0:
                o["y"] = -o["y"]; pos_y += 1; mod = True
            if crc_map and o["crc"] not in crc_map:
                missing += 1
            if any(sc == o["crc"] and ((sx-o["x"])**2+(sy-o["y"])**2+(sz-o["z"])**2)**0.5 < 15.0 for sx, sy, sz, sc in seen):
                dups += 1; mod = True; continue
            seen.append((o["x"], o["y"], o["z"], o["crc"]))
            clean.append(o)
        if mod and fix:
            if not os.path.exists(af + ".bak"):
                os.replace(af, af + ".bak")
            write_areadata(af, clean)
            print(f"[FIXED] {entry}/areadata.txt ({len(objs)} -> {len(clean)})")
    print(f"[OZET] Pozitif-Y: {pos_y} | Kopya Obje: {dups} | Eksik CRC: {missing}")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--map-dir", required=True)
    p.add_argument("--property-dir", default=None)
    p.add_argument("--fix", action="store_true")
    a = p.parse_args()
    run(a.map_dir, a.property_dir, a.fix)
