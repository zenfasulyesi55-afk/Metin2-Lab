"""
Blender 3.x / 4.x Headless Batch Prep Script (.OBJ -> Rigged/Animated .FBX for Granny2 .GR2!)
- Her bina ve aura mesh'ine Granny2'nin zorunlu tuttugu 'root' kemigini ekler (kemiksiz crash fix!).
- 120 Lvl Aura katmanlarina gercek donme/suzulme keyframe animasyonu gomerek .gr2 icinde
  otomatik hareket etmesini saglar!

Kullanim (Windows / GitHub Actions):
    blender --background --python scripts/blender_prepare_gr2_meshes.py -- ./GR2_DONUSUM_KAYNAK_V3 ./FBX_STAGE
"""
import os, sys, math, bpy

argv = sys.argv
args = argv[argv.index("--") + 1:] if "--" in argv else ["./GR2_DONUSUM_KAYNAK_V3", "./FBX_STAGE"]
IN_ROOT, OUT_ROOT = args[0], args[1]

def process_obj(obj_path, fbx_path):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if hasattr(bpy.ops.wm, "obj_import"):
        bpy.ops.wm.obj_import(filepath=obj_path, forward_axis='Y', up_axis='Z')
    else:
        bpy.ops.import_scene.obj(filepath=obj_path, axis_forward='Y', axis_up='Z')

    meshes = [o for o in bpy.context.scene.objects if o.type == 'MESH']
    if not meshes:
        return

    # Add mandatory Granny2 single root armature
    bpy.ops.object.armature_add(enter_editmode=False, location=(0, 0, 0))
    arm = bpy.context.active_object
    arm.name = "RootArmature"
    bone = arm.data.bones[0]
    bone.name = "root"

    for m in meshes:
        vg = m.vertex_groups.new(name="root")
        vg.add([v.index for v in m.data.vertices], 1.0, 'REPLACE')
        mod = m.modifiers.new(name="Armature", type='ARMATURE')
        mod.object = arm
        m.parent = arm

    # Embed native keyframe animation for Level 120 Aura layers!
    bn = os.path.basename(obj_path).lower()
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = 180
    bpy.context.scene.render.fps = 30
    pb = arm.pose.bones["root"]
    pb.rotation_mode = 'XYZ'

    if "floor_seal" in bn:
        pb.rotation_euler = (0, 0, 0); pb.keyframe_insert("rotation_euler", frame=1)
        pb.rotation_euler = (0, 0, math.radians(360)); pb.keyframe_insert("rotation_euler", frame=180)
    elif "energy_vortex" in bn:
        pb.rotation_euler = (0, 0, 0); pb.keyframe_insert("rotation_euler", frame=1)
        pb.rotation_euler = (0, 0, math.radians(-720)); pb.keyframe_insert("rotation_euler", frame=180)
    elif "crown_halo" in bn:
        pb.location = (0, 0, 0); pb.keyframe_insert("location", frame=1)
        pb.location = (0, 0, 8.0); pb.keyframe_insert("location", frame=90)
        pb.location = (0, 0, 0); pb.keyframe_insert("location", frame=180)

    os.makedirs(os.path.dirname(fbx_path), exist_ok=True)
    bpy.ops.export_scene.fbx(
        filepath=fbx_path,
        use_selection=False,
        bake_anim=("lvl120_aura" in bn),
        add_leaf_bones=False,
        axis_forward='Y',
        axis_up='Z',
    )
    print(f"[FBX OK] {fbx_path}")

for root, _, files in os.walk(IN_ROOT):
    for fn in sorted(files):
        if fn.endswith(".obj") and "_col" not in fn and "00_lvl120" not in fn and "04_lvl120" not in fn:
            src = os.path.join(root, fn)
            rel = os.path.relpath(src, IN_ROOT)
            dst = os.path.join(OUT_ROOT, rel[:-4] + ".fbx")
            process_obj(src, dst)
