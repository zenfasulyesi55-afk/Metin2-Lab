#!/usr/bin/env python3
"""
Metin2 V3 Harita Otomatik Bug-Fix & Heightmap Z-Hizalama Araci
==============================================================
Duzelttigi kritik hatalar:
1. height.raw (16-bit Metin2 arazi yukseklik haritasi) okuyarak her objenin Z degerini
   gercek arazi yuksekligine tam oturtur (havada ucma / yer altina gomulme bugini %100 cozer!).
2. areadata.txt icindeki pozitif Y koordinatlarini negatife cevirir.
3. Ust uste binmis kopya objeleri (< 15 birim) siler (Z-fighting & FPS fix).
4. .prb dosyalarindaki a1/b1/c1 yol uyumsuzluklarini ve CRC32 cakismalarini denetler.
5. town.txt dogum noktalarini attr.atr icindeki BLOCK/WATER/OBJECT bayraklarina karsi dogrular.

Kullanim:
    python3 metin2_v3_map_bugfix_tool.py --map-dir ./metin2_map_c1 --property-dir ./property --snap-z --fix
"""
import os, re, struct, argparse

ATTR_BLOCK, ATTR_WATER, ATTR_OBJECT = 0x01, 0x02, 0x80


def read_height_scale(map_dir):
    setting = os.path.join(map_dir, "setting.txt")
    if os.path.isfile(setting):
        with open(setting, "r", encoding="utf-8", errors="ignore") as f:
            for ln in f:
                parts = ln.strip().split()
                if len(parts) >= 2 and parts[0].lower() == "heightscale":
                    try:
                        return float(parts[1])
                    except ValueError:
                        pass
    return 0.5


def sample_chunk_height(chunk_dir, local_x, local_y, height_scale=0.5):
    """Samples Metin2 131x131 (128+3 border) 16-bit unsigned little-endian height.raw."""
    hpath = os.path.join(chunk_dir, "height.raw")
    if not os.path.isfile(hpath):
        return None
    data = open(hpath, "rb").read()
    # Standard Metin2 height.raw is 131x131 uint16 (34322 bytes)
    dim = int(round((len(data) // 2) ** 0.5))
    if dim < 128:
        return None
    # Map local_x/y in [0, 25600] to [0, 128]
    gx = max(0, min(dim - 1, int(round(local_x / 200.0)) + (1 if dim == 131 else 0)))
    gy = max(0, min(dim - 1, int(round(local_y / 200.0)) + (1 if dim == 131 else 0)))
    raw_val = struct.unpack_from("<H", data, (gy * dim + gx) * 2)[0]
    return raw_val * height_scale


def scan_properties(prop_dir):
    crc_map, dups, path_warnings = {}, [], []
    if not prop_dir or not os.path.isdir(prop_dir):
        return crc_map, dups, path_warnings
    for root, _, files in os.walk(prop_dir):
        for fn in files:
            if not fn.lower().endswith((".prb", ".pre", ".prd", ".prt", ".pra")):
                continue
            full = os.path.join(root, fn)
            txt = open(full, "r", encoding="utf-8", errors="ignore").read()
            lines = [ln.strip() for ln in txt.splitlines() if ln.strip()]
            if len(lines) >= 2 and lines[0] == "YPRT":
                crc = lines[1]
                if crc in crc_map:
                    dups.append((crc, crc_map[crc], full))
                else:
                    crc_map[crc] = full
                if "/zone/a1/" in txt.lower() or "/zone/b1/" in txt.lower():
                    path_warnings.append(full)
    return crc_map, dups, path_warnings


def parse_areadata(path):
    txt = open(path, "r", encoding="utf-8", errors="ignore").read()
    pat = re.compile(
        r"Start\s+Object\d+\s+([-+]?\d*\.?\d+)\s+([-+]?\d*\.?\d+)\s+([-+]?\d*\.?\d+)\s+"
        r"(\d+)\s+([^\n]+)\s+([-+]?\d*\.?\d+)\s+End\s+Object", re.M)
    return [{"x": float(m[1]), "y": float(m[2]), "z": float(m[3]), "crc": m[4],
             "rot": m[5].strip(), "bias": float(m[6])} for m in pat.finditer(txt)]


def write_areadata(path, objs):
    with open(path, "w", encoding="utf-8") as f:
        f.write("AreaDataFile\n")
        for i, o in enumerate(objs):
            f.write(f"Start Object{i:03d}\n    {o['x']:.6f} {o['y']:.6f} {o['z']:.6f}\n"
                    f"    {o['crc']}\n    {o['rot']}\n    {o['bias']:.6f}\nEnd Object\n")


def run(map_dir, prop_dir, snap_z, fix):
    hscale = read_height_scale(map_dir)
    crc_map, dup_crcs, pwarn = scan_properties(prop_dir)
    print(f"[INFO] Harita: {map_dir} | HeightScale={hscale} | CRC={len(crc_map)} | Cakisma={len(dup_crcs)}")
    for pw in pwarn:
        print(f"  [UYARI] .prb yol hatasi (a1/b1 yerine a/b olmali): {pw}")

    pos_y = dups = missing = snapped = 0
    for entry in sorted(os.listdir(map_dir)):
        cdir = os.path.join(map_dir, entry)
        af = os.path.join(cdir, "areadata.txt")
        if not (os.path.isdir(cdir) and len(entry) == 6 and entry.isdigit() and os.path.isfile(af)):
            continue
        cx_i, cy_i = int(entry[:3]), int(entry[3:])
        objs = parse_areadata(af)
        clean, seen, mod = [], [], False
        for o in objs:
            if o["y"] > 0:
                o["y"] = -o["y"]; pos_y += 1; mod = True
            if crc_map and o["crc"] not in crc_map:
                missing += 1
            if snap_z:
                lx = o["x"] - cx_i * 25600.0
                ly = (-o["y"]) - cy_i * 25600.0
                h_real = sample_chunk_height(cdir, lx, ly, hscale)
                if h_real is not None and abs(o["z"] - h_real) > 200.0:
                    # Preserve small intentional local elevation (e.g. +16 corner brazier)
                    rel_z = o["z"] if abs(o["z"]) <= 150.0 else 0.0
                    o["z"] = h_real + rel_z
                    snapped += 1; mod = True
            if any(sc == o["crc"] and ((sx-o["x"])**2+(sy-o["y"])**2+(sz-o["z"])**2)**0.5 < 15.0 for sx, sy, sz, sc in seen):
                dups += 1; mod = True; continue
            seen.append((o["x"], o["y"], o["z"], o["crc"]))
            clean.append(o)
        if mod and fix:
            if not os.path.exists(af + ".bak"):
                os.replace(af, af + ".bak")
            write_areadata(af, clean)
            print(f"[FIXED] {entry}/areadata.txt ({len(objs)} -> {len(clean)} obje)")
    print(f"[OZET] Pozitif-Y: {pos_y} | Arazi Z-Hizalandi: {snapped} | Kopya Obje: {dups} | Eksik CRC: {missing}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--map-dir", required=True)
    ap.add_argument("--property-dir", default=None)
    ap.add_argument("--snap-z", action="store_true", help="height.raw okuyarak Z yuksekligini araziye tam oturt")
    ap.add_argument("--fix", action="store_true")
    a = ap.parse_args()
    run(a.map_dir, a.property_dir, a.snap_z, a.fix)
