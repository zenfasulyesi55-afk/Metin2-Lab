# ==============================================================================
# DOSYA: root/playersettingmodule.py  (veya uiscript/locale tarafi efekt kaydi)
# __LoadGameEffect() fonksiyonu icine ekleyin:
# ==============================================================================

chrmgr.RegisterEffect(
    chrmgr.EFFECT_AFFECT + 95,   # Bos Affect/Effect slot ID (Client C++ enum ile eslesmeli!)
    "",                          # Bos birakilir -> karakterin zemin/merkez (Bip01) noktasina baglanir
    "d:/ymir work/effect/etc/lvl120_aura/lvl120_gold_aura.mse"
)
